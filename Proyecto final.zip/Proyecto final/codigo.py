import tkinter as tk
from PIL import Image, ImageTk
import os
import re


def cargar_emoticones():
    return [
        ('<3', 'emojis/001-emoji.png'),
        (':)', 'emojis/003-feliz.png'),
        (':O', 'emojis/004-conmocionado.png'),
        (':D', 'emojis/005-sonriente.png'),
        (':-]', 'emojis/006-feliz-1.png'),
        (':(', 'emojis/009-triste.png'),
        ('>:(', 'emojis/011-enojado.png'),
        (':-O', 'emojis/012-conmocionado-1.png'),
        (':-|', 'emojis/013-preocuparse.png'),
        (';)', 'emojis/018-guino.png'),
        ('(y)', 'emojis/020-me-gusta.png'),
        ('(n)', 'emojis/028-pulgares-abajo.png'),
        ('xD', 'emojis/058-riendo.png'),
        (':*', 'emojis/067-beso.png'),
        (':p', 'emojis/068-lengua.png'),
        (':3', 'emojis/perro.png')
    ]


def reemplazar_emoticones(texto, emoticones):
    for emoticon, filename in emoticones:
        texto = re.sub(re.escape(emoticon), filename, texto)
    return texto


def cargar_diccionario():
    try:
        with open("diccionario_español.txt", "r", encoding="utf-8") as archivo:
            return set(archivo.read().split())
    except FileNotFoundError:
        print("El archivo 'diccionario_español.txt' no se encontró.")
        return set()


def contar_palabras_y_emojis(texto, diccionario):
    palabras = texto.split()
    palabras_validas = [palabra.lower() for palabra in palabras if palabra.lower() in diccionario]
    emojis = sum(1 for palabra in palabras if os.path.isfile(palabra))
    return len(palabras), len(palabras_validas), emojis


def mostrar_texto():
    entrada = entrada_texto.get("1.0", "end-1c")
    entrada_con_emoticones = reemplazar_emoticones(entrada, emoticones)


    # Contar solo las palabras en el diccionario
    diccionario = cargar_diccionario()
    total_palabras, palabras_validas, emojis = contar_palabras_y_emojis(entrada_con_emoticones, diccionario)


    # Eliminar contenido anterior
    for widget in contenedor_imagen.winfo_children():
        widget.destroy()


    # Mostrar imágenes y texto
    for palabra in entrada_con_emoticones.split():
        if os.path.isfile(palabra):
            try:
                imagen = Image.open(palabra)
                imagen = imagen.resize((15, 15), Image.NEAREST)
                foto = ImageTk.PhotoImage(imagen)
                etiqueta = tk.Label(contenedor_imagen, image=foto)
                etiqueta.image = foto
                etiqueta.pack(side="left")
            except Exception as e:
                print(f"Error al cargar la imagen {palabra}: {e}")
        else:
            etiqueta_texto = tk.Label(contenedor_imagen, text=palabra)
            etiqueta_texto.pack(side="left")


    # Imprimir mensaje
    mensaje = f"Se encontraron {palabras_validas} palabras y {emojis} emojis"
    resultado_var.set(mensaje)


# Crear la ventana
ventana = tk.Tk()
ventana.title("Proyecto final")


# Cargar la lista de emoticones una sola vez
emoticones = cargar_emoticones()


# Parte superior izquierda
ruta_imagen = "logo_eafit_completo.png"
imagen_original = Image.open(ruta_imagen)
nuevo_tamano = (100, 50)
imagen_redimensionada = imagen_original.resize(nuevo_tamano, resample=Image.LANCZOS)
imagen_superior = ImageTk.PhotoImage(imagen_redimensionada)


etiqueta_imagen = tk.Label(ventana, image=imagen_superior)
etiqueta_imagen.grid(row=0, column=0, padx=10, pady=10)


# Parte superior derecha
titulo_var = tk.StringVar()
titulo_var.set("PROYECTO FINAL\nLENGUAJES DE PROGRAMACION")
etiqueta_titulo = tk.Label(ventana, textvariable=titulo_var, font=("Helvetica", 12))
etiqueta_titulo.grid(row=0, column=1, padx=10, pady=10)


# Caja de entrada de texto
entrada_texto = tk.Text(ventana, height=5, width=40)
entrada_texto.grid(row=1, column=0, columnspan=2, padx=10, pady=10)


# Botón para procesar el texto
boton_mostrar = tk.Button(ventana, text="Procesar texto", command=mostrar_texto)
boton_mostrar.grid(row=2, column=0, columnspan=2, pady=10)


# Contenedor para las imágenes y el texto
contenedor_imagen = tk.Frame(ventana)
contenedor_imagen.grid(row=3, column=0, columnspan=2, padx=10, pady=10)


# Resultado de palabras y emojis
resultado_var = tk.StringVar()
resultado_var.set("Palabras: 0, Emojis: 0")
etiqueta_resultado = tk.Label(ventana, textvariable=resultado_var, font=("Helvetica", 10))
etiqueta_resultado.grid(row=4, column=0, columnspan=2, pady=10)


# Iniciar el bucle principal de la interfaz gráfica
ventana.mainloop()


### enlace al video: https://www.youtube.com/watch?v=6HgEpCyZAA4